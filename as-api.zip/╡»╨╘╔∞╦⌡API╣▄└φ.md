# 弹性伸缩API管理<a name="ZH-CN_TOPIC_0133153515"></a>

-   **[查询API版本信息](查询API版本信息.md)**  

-   **[查询指定API版本信息](查询指定API版本信息.md)**  


